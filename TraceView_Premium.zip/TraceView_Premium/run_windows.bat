@echo off
title TraceView - Setup and Launch
cd /d "%~dp0"
echo.
echo  TRACEVIEW - MINI STRACE-LIKE PROCESS MONITOR
echo  --------------------------------------------
echo.
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher was not found. Install Python 3.10+ from https://www.python.org/downloads/
  echo Make sure to tick "Add Python to PATH" during installation.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo [1/3] Creating virtual environment...
  py -m venv .venv
  if errorlevel 1 goto failed
)
echo [2/3] Installing required packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo [3/3] Starting the local web server...
echo Open http://127.0.0.1:5000 in your browser.
echo NOTE: Real system-call tracing requires Linux/WSL with strace installed.
echo Press Ctrl+C in this window to stop the server.
echo.
".venv\Scripts\python.exe" app.py
pause
exit /b 0
:failed
echo.
echo Setup failed. Check the error above, confirm internet access, and try again.
pause
exit /b 1
