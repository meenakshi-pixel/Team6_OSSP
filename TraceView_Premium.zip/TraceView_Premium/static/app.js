const $ = (id) => document.getElementById(id);
const COLORS = ['#64e8d1','#a89aff','#f4c879','#ff7f9d','#79aaff','#f09fe0','#84d89e','#e3e9f5'];
let latest = null, historyItems = [], activeFilter = 'all', toastTimer = null;

const commandMap = {
  ls: 'ls -la', pwd: 'pwd', date: 'date', uname: 'uname -a',
  whoami: 'whoami', id: 'id', echo: 'echo "TraceView demo output"',
  'python-version': 'python3 --version'
};

function showToast(message, isError=false) {
  $('toastText').textContent = message;
  $('toast').classList.toggle('error', isError);
  $('toast').classList.add('show');
  $('toast').querySelector('.toast-icon').textContent = isError ? '!' : '✓';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $('toast').classList.remove('show'), 3200);
}
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function updatePreview() {
  const command = $('commandSelect').value;
  $('commandPreview').textContent = commandMap[command] || command;
}
async function checkStatus() {
  try {
    const response = await fetch('/api/status');
    const data = await response.json();
    $('envName').textContent = data.os;
    $('envMeta').textContent = `Python ${data.python} · local runtime`;
    const ok = data.strace;
    $('straceStatus').innerHTML = `<span class="status-led ${ok?'ok':''}"></span>${ok?'strace engine ready':'strace not detected'}`;
    if (!ok) $('straceStatus').title = 'Install strace in Ubuntu/WSL to enable real tracing.';
  } catch {
    $('envMeta').textContent = 'Unable to connect to backend';
    $('straceStatus').innerHTML = '<span class="status-led"></span> Backend unavailable';
  }
}
function renderRows() {
  const body = $('traceRows');
  if (!latest || !latest.rows.length) {
    body.innerHTML = `<tr class="empty-row"><td colspan="5"><div class="empty-state"><div class="empty-visual"><span>⌁</span><i></i><i></i><i></i></div><strong>${latest?'No system calls returned':'Your trace stream is waiting'}</strong><p>${latest?'Try another approved command or check the backend environment.':'Select a command and press <b>Start tracing</b> to capture real Linux system calls.'}</p><span class="empty-hint">${latest?'Empty trace':'No fabricated events · Real strace output only'}</span></div></td></tr>`;
    $('rowCount').textContent = '0 EVENTS';
    $('tableSummary').textContent = '0 events captured';
    return;
  }
  const term = $('searchInput').value.trim().toLowerCase();
  const rows = latest.rows.filter(row => {
    const matchesFilter = activeFilter === 'all' || row.status === activeFilter;
    return matchesFilter && `${row.call} ${row.details} ${row.result}`.toLowerCase().includes(term);
  });
  body.innerHTML = rows.length ? rows.map(row => {
    const originalIndex = latest.rows.indexOf(row) + 1;
    const status = row.status === 'error' ? 'error' : row.status === 'info' ? 'info' : 'success';
    const statusText = status === 'error' ? 'Error' : status === 'info' ? 'Info' : 'Success';
    return `<tr><td class="row-num">${String(originalIndex).padStart(2,'0')}</td><td><span class="call-name">${esc(row.call)}()</span></td><td class="details-cell" title="${esc(row.details)}">${esc(row.details)}</td><td class="result-cell ${status==='error'?'error':''}" title="${esc(row.result)}">${esc(row.result)}</td><td><span class="status-pill ${status}">${statusText}</span></td></tr>`;
  }).join('') : `<tr><td colspan="5"><div class="empty-state compact"><strong>No matching events</strong><p>Try a different search term or filter.</p></div></td></tr>`;
  $('rowCount').textContent = `${rows.length} / ${latest.rows.length} EVENTS`;
  $('tableSummary').textContent = `${rows.length} visible · ${latest.rows.length} total events`;
}
function renderDistribution() {
  if (!latest) return;
  const counts = latest.counts || [];
  $('donutTotal').textContent = latest.total;
  if (!counts.length || !latest.total) {
    $('donut').style.background = 'conic-gradient(#263248 0 100%)';
    $('legend').innerHTML = '<div class="empty-legend">No call data available for this run.</div>';
    $('distributionFoot').textContent = 'No system call events returned';
    return;
  }
  let cursor = 0;
  const stops = counts.map((entry, i) => {
    const start = cursor; cursor += entry.count / latest.total * 100;
    return `${COLORS[i % COLORS.length]} ${start}% ${cursor}%`;
  });
  $('donut').style.background = `conic-gradient(${stops.join(',')})`;
  $('legend').innerHTML = counts.slice(0,5).map((entry,i) => `<div class="legend-item"><span class="legend-swatch" style="background:${COLORS[i%COLORS.length]}"></span><span class="legend-name">${esc(entry.name)}()</span><span class="legend-value">${entry.count}</span></div>`).join('');
  $('distributionFoot').textContent = `${counts.length} unique call types detected`;
}
function renderAnalytics() {
  if (!latest) return;
  const counts = latest.counts || [];
  if (!counts.length) {
    $('analyticsContent').innerHTML = '<div class="empty-state compact"><strong>No call analytics</strong><p>This run did not return any parsable system calls.</p></div>';
    return;
  }
  const max = Math.max(...counts.map(x => x.count), 1);
  $('analyticsContent').innerHTML = `<div class="stats-grid" style="margin-bottom:18px"><article class="stat-card"><div class="stat-label">TOTAL EVENTS</div><div class="stat-number">${latest.total}</div></article><article class="stat-card"><div class="stat-label">ERROR RATE</div><div class="stat-number">${latest.total?Math.round(latest.errors/latest.total*100):0}<small>%</small></div></article><article class="stat-card"><div class="stat-label">EXIT CODE</div><div class="stat-number">${latest.exit_code}</div></article><article class="stat-card"><div class="stat-label">UNIQUE TYPES</div><div class="stat-number">${counts.length}</div></article></div><table class="analytics-table"><thead><tr><th>SYSTEM CALL</th><th>FREQUENCY</th><th>COUNT</th></tr></thead><tbody>${counts.map((x,i)=>`<tr><td><span class="call-name">${esc(x.name)}()</span></td><td class="bar-cell"><div class="bar-track"><div class="bar-fill" style="width:${x.count/max*100}%;background:${COLORS[i%COLORS.length]}"></div></div></td><td>${x.count}</td></tr>`).join('')}</tbody></table>`;
}
function updateStats() {
  if (!latest) return;
  $('statCalls').textContent = latest.total;
  $('statErrors').textContent = latest.errors;
  $('statDuration').textContent = latest.duration_ms;
  $('statUnique').textContent = (latest.counts||[]).length;
  $('callsFoot').textContent = `${latest.command} completed`;
  $('errorsFoot').textContent = latest.errors ? 'Failed calls detected' : 'No failed calls detected';
  $('distributionFoot').textContent = `${(latest.counts||[]).length} unique call types detected`;
  $('traceTimestamp').textContent = new Date(latest.timestamp).toLocaleTimeString();
  $('exportBtn').disabled = !latest.rows.length;
  renderRows(); renderDistribution(); renderAnalytics();
}
async function runTrace() {
  const command = $('commandSelect').value;
  const btn = $('runBtn');
  btn.disabled = true;
  $('runBtnText').textContent = 'Tracing process…';
  btn.querySelector('.play-icon').textContent = '◌';
  try {
    const response = await fetch('/api/trace', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({command})
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
      showToast(data.error || 'Trace failed. Check the backend.', true);
      if (data.help) showToast(data.help, true);
      return;
    }
    latest = data;
    historyItems.unshift({...data, rows: data.rows.slice(), counts: data.counts.slice()});
    historyItems = historyItems.slice(0, 20);
    activeFilter = 'all'; $('searchInput').value = '';
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.toggle('active', b.dataset.filter === 'all'));
    updateStats();
    renderHistory();
    showToast(`Trace complete · ${data.total} events captured`);
  } catch (err) {
    showToast('Cannot reach the Flask backend. Is app.py running?', true);
  } finally {
    btn.disabled = false;
    $('runBtnText').textContent = 'Start tracing';
    btn.querySelector('.play-icon').textContent = '▶';
  }
}
function clearTrace() {
  latest = null;
  $('statCalls').textContent = '—'; $('statErrors').textContent = '—';
  $('statDuration').textContent = '—'; $('statUnique').textContent = '—';
  $('callsFoot').textContent = 'Awaiting first trace'; $('errorsFoot').textContent = 'No trace data yet';
  $('donutTotal').textContent = '0'; $('donut').style.background = 'conic-gradient(#263248 0 100%)';
  $('legend').innerHTML = '<div class="empty-legend">Run a trace to reveal the breakdown.</div>';
  $('distributionFoot').textContent = 'Waiting for trace data';
  $('traceTimestamp').textContent = 'READY'; $('exportBtn').disabled = true;
  $('searchInput').value = ''; activeFilter = 'all';
  document.querySelectorAll('.filter-btn').forEach(b=>b.classList.toggle('active',b.dataset.filter==='all'));
  $('analyticsContent').innerHTML = '<div class="empty-state compact"><strong>No analytics yet</strong><p>Run a trace to see call frequency and execution metrics.</p></div>';
  renderRows(); showToast('Trace view cleared');
}
function exportCSV() {
  if (!latest || !latest.rows.length) return showToast('There are no trace events to export.', true);
  const fields = ['index','call','details','result','status'];
  const quote = value => `"${String(value??'').replace(/"/g,'""')}"`;
  const lines = [fields.join(',')].concat(latest.rows.map((row,i)=>[i+1,row.call,row.details,row.result,row.status].map(quote).join(',')));
  const blob = new Blob(['\ufeff'+lines.join('\r\n')], {type:'text/csv;charset=utf-8;'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = `traceview-${latest.command}-${Date.now()}.csv`;
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  showToast('CSV export started');
}
function renderHistory() {
  if (!historyItems.length) {
    $('historyContent').innerHTML = '<div class="empty-state compact"><strong>No previous traces</strong><p>Your completed traces will appear here.</p></div>';
    return;
  }
  $('historyContent').innerHTML = historyItems.map((item,i)=>`<div class="history-item"><div><strong>${esc(item.command)}</strong><p>${new Date(item.timestamp).toLocaleString()} · ${item.total} events · ${item.duration_ms} ms</p></div><button data-history="${i}">Load trace ↗</button></div>`).join('');
  $('historyContent').querySelectorAll('[data-history]').forEach(button => button.addEventListener('click',()=>{
    latest = historyItems[Number(button.dataset.history)];
    updateStats(); showTab('monitor'); showToast('Previous trace loaded');
  }));
}
function showTab(tab) {
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
  $('monitorPanel').classList.toggle('hidden',tab!=='monitor');
  $('tracePanel').classList.toggle('hidden',tab!=='monitor');
  $('analyticsPanel').classList.toggle('hidden',tab!=='analytics');
  $('historyPanel').classList.toggle('hidden',tab!=='history');
  const labels={monitor:'Live monitor',analytics:'Analytics',history:'Trace history'};
  $('crumbPage').textContent=labels[tab]||'Live monitor';
  if(tab==='analytics') renderAnalytics();
  if(tab==='history') renderHistory();
}
$('commandSelect').addEventListener('change', updatePreview);
$('runBtn').addEventListener('click', runTrace);
$('clearBtn').addEventListener('click', clearTrace);
$('exportBtn').addEventListener('click', exportCSV);
$('searchInput').addEventListener('input', renderRows);
document.querySelectorAll('.filter-btn').forEach(button => button.addEventListener('click',()=>{
  activeFilter=button.dataset.filter;
  document.querySelectorAll('.filter-btn').forEach(b=>b.classList.toggle('active',b===button));
  renderRows();
}));
document.querySelectorAll('.nav-item').forEach(button=>button.addEventListener('click',()=>showTab(button.dataset.tab)));
$('clearHistoryBtn').addEventListener('click',()=>{historyItems=[];renderHistory();showToast('Trace history cleared');});
$('themeToggle').addEventListener('click',()=>{document.body.classList.toggle('light-mode');showToast(document.body.classList.contains('light-mode')?'Light theme enabled':'Dark theme enabled');});
document.addEventListener('keydown',event=>{
  if(event.key==='Enter' && !['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName)) runTrace();
  if(event.key==='/' && !['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName)){event.preventDefault();$('searchInput').focus();}
  if(event.key==='Escape') $('searchInput').blur();
});
updatePreview(); checkStatus();