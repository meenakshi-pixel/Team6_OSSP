# TraceView — Mini strace-Like Process Monitoring Tool

A polished local web dashboard for an Operating Systems project. The Flask backend runs a small allowlist of commands through Linux `strace`; the frontend displays real parsed system-call output, return values, error counts, call distribution, filtering, analytics, CSV export, and session history.

## Requirements
- Python 3.10+
- Linux (Ubuntu recommended) or Windows with **WSL2 + Ubuntu**
- `strace` installed in the Linux environment
- Internet access on first launch to install Flask (Google Fonts are optional)

## Run on Windows Command Prompt
1. Install Python from https://www.python.org/downloads/ and enable **Add Python to PATH**.
2. Extract this ZIP to a normal folder (not inside a ZIP preview).
3. Double-click `run_windows.bat`, or in Command Prompt:
   ```bat
   cd path\to\TraceView_Premium
   run_windows.bat
   ```
4. Open **http://127.0.0.1:5000** in your browser.
5. Stop the server with **Ctrl+C** in the command window.

### Important: Windows and real system calls
The dashboard itself can start on Windows, but real `strace` tracing is Linux-specific. For the actual final-exam demonstration, use WSL2 Ubuntu:
1. Open PowerShell as Administrator and run `wsl --install -d Ubuntu`, then restart if prompted.
2. Open Ubuntu and run:
   ```bash
   sudo apt update
   sudo apt install python3 python3-venv python3-pip strace
   ```
3. Copy/extract the project into your Ubuntu home folder. If it is in Windows Downloads, you can access it under `/mnt/c/Users/YOUR_WINDOWS_USERNAME/Downloads/`.
4. In Ubuntu, `cd` to the project folder and run:
   ```bash
   chmod +x run_linux.sh
   ./run_linux.sh
   ```
5. Open http://127.0.0.1:5000 in your Windows browser.

## Features
- Premium responsive dashboard, dark/light theme toggle
- Approved command selector (no arbitrary shell commands)
- Real `strace` output parsed by the backend
- Summary cards, unique-call breakdown, call distribution
- Search and status filters
- Analytics view and session-only trace history
- CSV export of the latest trace
- Clear current trace / clear history
- Timeout, command allowlist, loopback-only server

## Safety and accuracy notes
- The command runner deliberately accepts only predefined command IDs and never uses `shell=True`.
- Do not expose this development server to the public internet.
- This is a simplified educational tracer, not a full replacement for the real `strace`.
- On Windows without WSL/Linux, the dashboard will load but the trace action will report that `strace` is unavailable. This is expected.
- Trace rows and counts are real parsed output; the app does not invent demo syscall events.
