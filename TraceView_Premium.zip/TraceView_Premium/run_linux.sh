#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "TraceView — Mini strace-like process monitor"
if ! command -v python3 >/dev/null 2>&1; then echo "Python 3 is required."; exit 1; fi
if ! command -v strace >/dev/null 2>&1; then
  echo "Installing strace is required for real traces. On Ubuntu/WSL run:"
  echo "  sudo apt update && sudo apt install strace python3-venv"
  exit 1
fi
if [ ! -d .venv ]; then python3 -m venv .venv; fi
. .venv/bin/activate
pip install -r requirements.txt
echo "Open http://127.0.0.1:5000 in your browser. Ctrl+C stops the server."
python app.py
