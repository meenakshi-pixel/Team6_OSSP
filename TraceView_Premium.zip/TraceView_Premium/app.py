from flask import Flask, render_template, request, jsonify
import subprocess, shlex, shutil, platform, os, time, re
from datetime import datetime

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

# Intentionally allowlisted commands only. Never pass arbitrary shell text to a shell.
ALLOWED = {
    "ls": ["ls", "-la"],
    "pwd": ["pwd"],
    "date": ["date"],
    "uname": ["uname", "-a"],
    "whoami": ["whoami"],
    "id": ["id"],
    "echo": ["echo", "TraceView demo output"],
    "python-version": ["python3", "--version"],
}
CALL_NAME = re.compile(r"^([a-zA-Z_][a-zA-Z0-9_]*)\(")

def parse_strace(text):
    rows = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        # strace lines can start with a PID when -f is used; this app traces one process.
        m = CALL_NAME.match(line)
        if m:
            name = m.group(1)
            result = line.split(" = ")[-1] if " = " in line else "unfinished"
            status = "error" if result.startswith("-1") else "success"
            rows.append({"call": name, "details": line, "result": result, "status": status})
        elif line.startswith("+++"):
            rows.append({"call": "process", "details": line, "result": "exit", "status": "info"})
        elif line.startswith("---"):
            rows.append({"call": "signal", "details": line, "result": "signal", "status": "info"})
    return rows

@app.route("/")
def index():
    return render_template("index.html", tracing_available=bool(shutil.which("strace")), os_name=platform.system())

@app.get("/api/status")
def status():
    return jsonify({
        "ok": True,
        "os": platform.system(),
        "python": platform.python_version(),
        "strace": bool(shutil.which("strace")),
        "commands": [{"id": k, "label": k.replace("-", " ").upper()} for k in ALLOWED]
    })

@app.post("/api/trace")
def trace():
    data = request.get_json(silent=True) or {}
    command_key = data.get("command", "")
    if command_key not in ALLOWED:
        return jsonify({"ok": False, "error": "Choose one of the approved commands."}), 400
    command = ALLOWED[command_key]
    started = time.perf_counter()
    strace = shutil.which("strace")
    if not strace:
        return jsonify({
            "ok": False,
            "error": "strace is not installed or this is not a supported Linux environment.",
            "help": "Use Ubuntu/WSL: sudo apt update && sudo apt install strace. On Windows, run this project inside Ubuntu on WSL."
        }), 400
    try:
        # -qq suppresses strace's own attach/exit messages; -s limits captured string length.
        proc = subprocess.run(
            [strace, "-qq", "-s", "160", "-o", "-", "--"] + command,
            capture_output=True, text=True, timeout=8, cwd=os.path.dirname(os.path.abspath(__file__))
        )
        elapsed = round((time.perf_counter() - started) * 1000, 2)
        raw = proc.stderr + "\n" + proc.stdout
        rows = parse_strace(raw)
        # Some strace builds send trace lines to stderr when -o - is not supported as expected.
        if not rows:
            retry = subprocess.run([strace, "-qq", "-s", "160", "--"] + command,
                                   capture_output=True, text=True, timeout=8,
                                   cwd=os.path.dirname(os.path.abspath(__file__)))
            rows = parse_strace(retry.stderr)
            raw = retry.stderr
            proc = retry
        counts = {}
        for row in rows:
            counts[row["call"]] = counts.get(row["call"], 0) + 1
        return jsonify({
            "ok": True, "command": command_key, "exit_code": proc.returncode,
            "duration_ms": elapsed, "timestamp": datetime.now().astimezone().isoformat(timespec="seconds"),
            "rows": rows, "total": len(rows),
            "errors": sum(1 for row in rows if row["status"] == "error"),
            "counts": [{"name": k, "count": v} for k, v in sorted(counts.items(), key=lambda x: (-x[1], x[0]))],
            "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-2000:]
        })
    except subprocess.TimeoutExpired:
        return jsonify({"ok": False, "error": "Command exceeded the 8-second safety timeout."}), 408
    except Exception as exc:
        app.logger.exception("Trace failed")
        return jsonify({"ok": False, "error": "Trace failed: " + str(exc)}), 500

@app.errorhandler(404)
def not_found(_):
    return jsonify({"ok": False, "error": "Endpoint not found."}), 404

if __name__ == "__main__":
    # Local development server only; keep it on loopback for safety.
    app.run(host="127.0.0.1", port=5000, debug=False)
