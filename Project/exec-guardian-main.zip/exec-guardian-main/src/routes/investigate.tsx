import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { CheckCircle2, HelpCircle } from "lucide-react";
import { Bits, Btn, Empty, PageHeader, Panel, Pill } from "@/components/eg/ui";
import { SAMPLE_FILES } from "@/lib/execguard/data";
import { RULES } from "@/lib/execguard/rules";
import { useStore } from "@/lib/execguard/store";
import { fmtTime } from "@/lib/execguard/format";
import type { LogEntry } from "@/lib/execguard/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/investigate")({
  validateSearch: (s: Record<string, unknown>): { id?: string | undefined } => ({ id: typeof s["id"] === "string" ? (s["id"] as string) : undefined }),
  head: () => ({
    meta: [
      { title: "Why Was Access Denied? — ExecGuard" },
      { name: "description", content: "Investigate denied operations: facts, triggered rule and possible explanations." },
      { property: "og:title", content: "Why Was Access Denied? — ExecGuard" },
      { property: "og:description", content: "Investigate denied operations: facts, triggered rule and possible explanations." },
    ],
  }),
  component: Investigate,
});

function explanations(l: LogEntry): string[] {
  switch (l.rule) {
    case "WX-001":
      return [
        "A build or deploy step may have tried to patch the binary in place instead of replacing it.",
        "An editor or script may have opened the file for writing by mistake.",
        "Malware or an exploit could attempt to modify executables to persist — this cannot be confirmed from this event alone.",
      ];
    case "PERM-W":
      return ["The file may be intentionally read-only (e.g. a finalized report).", "Permissions may have been changed by a previous chmod.", "The process may be running as a different user than expected."];
    case "PERM-R":
    case "PERM-X":
      return ["The user is not the owner and 'other' class lacks the required bit.", "The file may be sensitive and restricted by design.", "A group membership may be missing (group bits are not evaluated in this demo)."];
    default:
      return [];
  }
}

function Investigate() {
  const { id } = Route.useSearch();
  const nav = useNavigate();
  const denied = useStore((s) => s.logs).filter((l) => l.result === "denied");
  const sel = denied.find((l) => l.id === id) ?? denied[0];
  const file = sel && SAMPLE_FILES.find((f) => f.name === sel.file);

  return (
    <>
      <PageHeader title="Why Was Access Denied?" desc="Pick a denied event to see what is confirmed by the log record and what are only possible explanations." />
      {denied.length === 0 ? (
        <Empty title="No denied events" desc="Run a Write check on an executable in the Access Simulator to generate one."><Link to="/simulator"><Btn>Open simulator</Btn></Link></Empty>
      ) : (
        <div className="grid gap-4 lg:grid-cols-3">
          <Panel title={`Denied events (${denied.length})`} className="lg:col-span-1">
            <ul className="-m-2 max-h-[640px] space-y-1 overflow-auto p-2">
              {denied.map((l) => (
                <li key={l.id}>
                  <button onClick={() => nav({ to: "/investigate", search: { id: l.id }, replace: true })} className={cn("w-full rounded-md border px-3 py-2 text-left", sel?.id === l.id ? "border-danger/40 bg-danger/10" : "border-transparent hover:bg-accent")}>
                    <div className="flex items-center justify-between text-xs"><span className="font-mono font-medium">{l.file}</span><span className="uppercase text-muted-foreground">{l.op}</span></div>
                    <div className="mt-0.5 flex items-center justify-between text-[11px] text-muted-foreground"><span>{l.rule}</span><span>{fmtTime(l.ts)}</span></div>
                  </button>
                </li>
              ))}
            </ul>
          </Panel>

          {sel && (
            <div className="space-y-4 lg:col-span-2">
              <section className="rounded-xl border border-danger/30 bg-danger/5 p-5">
                <div className="flex flex-wrap items-center gap-2">
                  <Pill tone="denied">DENIED</Pill>
                  <span className="font-mono text-sm">{sel.op.toUpperCase()} → {sel.file}</span>
                  <Pill tone="warning" className="ml-auto">Demo data</Pill>
                </div>
                <p className="mt-3 text-sm">{sel.reason}</p>
              </section>

              <Panel title={<span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-success" />Confirmed facts <span className="text-xs font-normal text-muted-foreground">— recorded in the event</span></span>}>
                <dl className="grid gap-3 text-sm sm:grid-cols-2">
                  <Fact k="File path" v={<span className="break-all font-mono text-xs">{sel.path ?? "—"}</span>} />
                  <Fact k="Attempted operation" v={<span className="uppercase">{sel.op}</span>} />
                  <Fact k="Permission state" v={sel.bits ? <Bits bits={sel.bits} /> : "—"} />
                  <Fact k="Rule triggered" v={sel.rule ? <><span className="font-mono">{sel.rule}</span> — {RULES[sel.rule]}</> : "—"} />
                  <Fact k="Timestamp" v={fmtTime(sel.ts)} />
                  <Fact k="Protection at time of event" v={sel.protection == null ? "Unknown" : sel.protection ? "Enabled" : "Disabled"} />
                  <Fact k="User" v={sel.user ?? "Not recorded"} />
                  <Fact k="Process" v={sel.process ?? "Not recorded"} />
                  {file && <Fact k="File owner" v={file.owner} />}
                </dl>
              </Panel>

              <Panel title={<span className="flex items-center gap-2"><HelpCircle className="h-4 w-4 text-warning" />Possible explanations <span className="text-xs font-normal text-muted-foreground">— not verified</span></span>}>
                <ul className="list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
                  {explanations(sel).map((e) => <li key={e}>{e}</li>)}
                </ul>
                <p className="mt-3 text-xs text-muted-foreground">These are hypotheses for an investigator to check. The event does not record intent or who initiated the action beyond the fields above.</p>
              </Panel>

              <div className="flex flex-wrap gap-2">
                {file && <Link to="/simulator" search={{ file: file.id }}><Btn variant="outline">Re-run in simulator</Btn></Link>}
                <Link to="/logs" search={{ q: sel.file }}><Btn variant="outline">Related audit entries</Btn></Link>
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
}

function Fact({ k, v }: { k: string; v: React.ReactNode }) {
  return <div className="rounded-md bg-muted/40 p-2.5"><dt className="text-xs text-muted-foreground">{k}</dt><dd className="mt-1">{v}</dd></div>;
}
