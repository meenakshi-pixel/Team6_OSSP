import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { AlertTriangle, GitCompare, Loader2 } from "lucide-react";
import { Btn, PageHeader, Panel, Pill } from "@/components/eg/ui";
import { analyze, diffLines, SAMPLES, type DiffRow } from "@/lib/execguard/diff";
import { actions } from "@/lib/execguard/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/analyzer")({
  head: () => ({
    meta: [
      { title: "Code Change Analyzer — ExecGuard" },
      { name: "description", content: "Compare original and modified code versions and review possible security effects." },
      { property: "og:title", content: "Code Change Analyzer — ExecGuard" },
      { property: "og:description", content: "Compare original and modified code versions and review possible security effects." },
    ],
  }),
  component: Analyzer,
});

type Lang = keyof typeof SAMPLES;
const FILE_FOR: Record<Lang, string> = { c: "main.c", python: "deploy.py", shell: "script.sh" };

function Analyzer() {
  const [lang, setLang] = useState<Lang>("c");
  const [a, setA] = useState<string>(SAMPLES.c.original);
  const [b, setB] = useState<string>(SAMPLES.c.modified);
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<{ rows: DiffRow[]; s: ReturnType<typeof analyze> } | null>(null);

  const load = (l: Lang) => { setLang(l); setA(SAMPLES[l].original); setB(SAMPLES[l].modified); setRes(null); };

  const compare = () => {
    if (!a.trim() || !b.trim()) { toast.error("Both versions need content to compare."); return; }
    setBusy(true);
    setTimeout(() => {
      const rows = diffLines(a, b);
      const s = analyze(rows);
      setRes({ rows, s });
      setBusy(false);
      actions.log({ kind: "compare", file: FILE_FOR[lang], op: "compare", result: s.total ? "changed" : "info", reason: s.total ? `Comparison: ${s.added} added, ${s.removed} removed, ${s.changed} changed line(s).${s.effects.length ? ` ${s.effects.length} risk indicator(s).` : ""}` : "Comparison: no differences.", user: "student", details: s.effects.join(" | ") });
      toast(s.total ? `${s.total} difference(s) found` : "Versions are identical", { description: "Logged to audit trail." });
    }, 300);
  };

  return (
    <>
      <PageHeader title="Code Change Analyzer" desc="Compare two versions of a file. Text is only diffed — never compiled or executed." />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <span className="text-xs text-muted-foreground">Load sample:</span>
        {(Object.keys(SAMPLES) as Lang[]).map((l) => (
          <button key={l} onClick={() => load(l)} className={cn("rounded-md border px-3 py-1 text-xs", lang === l ? "border-primary/50 bg-primary/10" : "border-border hover:bg-accent")}>{SAMPLES[l].label}</button>
        ))}
        <Btn className="ml-auto" onClick={compare} disabled={busy}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <GitCompare className="h-4 w-4" />}Compare Versions</Btn>
      </div>
      <div className="mb-4 grid gap-4 md:grid-cols-2">
        <Editor label="Original Version" value={a} onChange={(v) => { setA(v); setRes(null); }} />
        <Editor label="Modified Version" value={b} onChange={(v) => { setB(v); setRes(null); }} />
      </div>

      {res && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Panel title="Line diff" className="lg:col-span-2" actions={<div className="flex gap-1.5"><Pill tone="allowed">+{res.s.added}</Pill><Pill tone="denied">−{res.s.removed}</Pill><Pill tone="warning">~{res.s.changed}</Pill></div>}>
            <div className="-m-4 overflow-x-auto font-mono text-xs">
              {res.rows.map((r, i) => <Row key={i} r={r} />)}
            </div>
          </Panel>
          <Panel title="Summary">
            {res.s.total === 0 ? (
              <p className="text-sm text-muted-foreground">No differences detected.</p>
            ) : (
              <div className="space-y-4 text-sm">
                <p>{res.s.added} line(s) added, {res.s.removed} removed and {res.s.changed} modified.</p>
                <div>
                  <div className="mb-2 text-xs font-medium text-muted-foreground">Possible effects</div>
                  {res.s.effects.length ? (
                    <ul className="space-y-2">{res.s.effects.map((e) => <li key={e} className="flex gap-2 rounded-md border border-warning/30 bg-warning/5 p-2 text-xs"><AlertTriangle className="h-3.5 w-3.5 shrink-0 text-warning" />{e}</li>)}</ul>
                  ) : <p className="text-xs text-muted-foreground">No known risky patterns in the new or changed lines.</p>}
                </div>
                <p className="rounded-md bg-muted/50 p-2.5 text-xs text-muted-foreground">Pattern matching only. This analysis cannot tell who made the change or why — no authorship or intent evidence is available.</p>
              </div>
            )}
          </Panel>
        </div>
      )}
    </>
  );
}

function Editor({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="flex items-center justify-between border-b border-border px-3 py-2 text-xs"><span className="font-medium">{label}</span><span className="text-muted-foreground">{value.split("\n").length} lines</span></div>
      <textarea spellCheck={false} value={value} onChange={(e) => onChange(e.target.value)} className="h-72 w-full resize-y bg-background/40 p-3 font-mono text-xs leading-5 outline-none" aria-label={label} />
    </div>
  );
}

function Row({ r }: { r: DiffRow }) {
  const base = "grid grid-cols-[3rem_3rem_1.5rem_1fr] whitespace-pre px-2 leading-6";
  if (r.type === "same") return <div className={cn(base, "text-muted-foreground")}><span>{r.a}</span><span>{r.b}</span><span /> <span>{r.text}</span></div>;
  if (r.type === "add") return <div className={cn(base, "bg-success/10 text-success")}><span /><span>{r.b}</span><span>+</span><span>{r.text}</span></div>;
  if (r.type === "remove") return <div className={cn(base, "bg-danger/10 text-danger")}><span>{r.a}</span><span /><span>−</span><span>{r.text}</span></div>;
  return (
    <div className="border-l-2 border-warning">
      <div className={cn(base, "bg-danger/10 text-danger")}><span>{r.a}</span><span /><span>~</span><span>{r.from}</span></div>
      <div className={cn(base, "bg-success/10 text-success")}><span /><span>{r.b}</span><span>~</span><span>{r.to}</span></div>
    </div>
  );
}
