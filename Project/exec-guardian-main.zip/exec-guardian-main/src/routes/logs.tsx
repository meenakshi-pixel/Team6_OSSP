import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Download, Trash2, X } from "lucide-react";
import { Bits, Btn, Empty, inputCls, PageHeader, Pill, ResultPill } from "@/components/eg/ui";
import { actions, useStore } from "@/lib/execguard/store";
import { downloadText, fmtTime, logsToCsv } from "@/lib/execguard/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/logs")({
  validateSearch: (s: Record<string, unknown>): { q?: string | undefined } => ({ q: typeof s["q"] === "string" ? (s["q"] as string) : undefined }),
  head: () => ({
    meta: [
      { title: "Audit Logs — ExecGuard" },
      { name: "description", content: "Searchable audit trail of simulated access checks and code comparisons with CSV export." },
      { property: "og:title", content: "Audit Logs — ExecGuard" },
      { property: "og:description", content: "Searchable audit trail of simulated access checks and code comparisons with CSV export." },
    ],
  }),
  component: Logs,
});

const RESULTS = ["all", "allowed", "denied", "changed", "info"] as const;

function Logs() {
  const { q = "" } = Route.useSearch();
  const nav = useNavigate();
  const logs = useStore((s) => s.logs);
  const [result, setResult] = useState<(typeof RESULTS)[number]>("all");
  const [kind, setKind] = useState("all");
  const [sel, setSel] = useState<string | null>(null);

  const rows = useMemo(() => logs.filter((l) => {
    if (result !== "all" && l.result !== result) return false;
    if (kind !== "all" && l.kind !== kind) return false;
    if (q && !`${l.file} ${l.path} ${l.op} ${l.reason} ${l.user} ${l.process} ${l.rule}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  }), [logs, result, kind, q]);
  const detail = logs.find((l) => l.id === sel);

  const exportCsv = () => {
    if (!rows.length) { toast.error("Nothing to export."); return; }
    downloadText(`execguard-audit-${new Date().toISOString().slice(0, 10)}.csv`, logsToCsv(rows));
    toast.success(`Exported ${rows.length} entr${rows.length === 1 ? "y" : "ies"}`);
  };

  return (
    <>
      <PageHeader
        title="Audit Logs"
        desc="Every simulated access check, code comparison and policy change. All entries are demo data stored in this browser."
        actions={<>
          <Btn variant="outline" onClick={exportCsv}><Download className="h-4 w-4" />Export CSV</Btn>
          <Btn variant="danger" onClick={() => { if (confirm("Clear all audit log entries?")) { actions.clearLogs(); toast("Audit log cleared"); } }}><Trash2 className="h-4 w-4" />Clear</Btn>
        </>}
      />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <input className={cn(inputCls, "w-full sm:w-72")} placeholder="Search file, reason, user, process…" value={q} onChange={(e) => nav({ to: "/logs", search: { q: e.target.value || undefined }, replace: true })} />
        <select className={inputCls} value={result} onChange={(e) => setResult(e.target.value as typeof result)} aria-label="Result filter">
          {RESULTS.map((r) => <option key={r} value={r}>{r === "all" ? "All results" : r}</option>)}
        </select>
        <select className={inputCls} value={kind} onChange={(e) => setKind(e.target.value)} aria-label="Type filter">
          <option value="all">All types</option><option value="access">Access</option><option value="compare">Comparison</option><option value="settings">Settings</option>
        </select>
        <span className="ml-auto text-xs text-muted-foreground">{rows.length} of {logs.length}</span>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <div className={cn("overflow-x-auto rounded-xl border border-border bg-card", detail ? "xl:col-span-2" : "xl:col-span-3")}>
          {rows.length === 0 ? (
            <div className="p-4"><Empty title={logs.length ? "No matching entries" : "Audit log is empty"} desc={logs.length ? "Adjust search or filters." : "Run a simulation or comparison to create entries."}>
              {logs.length ? <Btn variant="outline" onClick={() => { setResult("all"); setKind("all"); nav({ to: "/logs", search: {} }); }}>Reset filters</Btn> : <Btn variant="outline" onClick={() => actions.resetDemo()}>Restore sample data</Btn>}
            </Empty></div>
          ) : (
            <table className="w-full min-w-[760px] text-sm">
              <thead className="border-b border-border text-left text-xs text-muted-foreground">
                <tr>{["Timestamp", "File", "Operation", "Result", "Reason", "Process / User", ""].map((h) => <th key={h} className="px-3 py-2.5 font-medium">{h}</th>)}</tr>
              </thead>
              <tbody>
                {rows.map((l) => (
                  <tr key={l.id} onClick={() => setSel(l.id)} className={cn("cursor-pointer border-b border-border/60 last:border-0 hover:bg-accent/50", sel === l.id && "bg-accent")}>
                    <td className="whitespace-nowrap px-3 py-2.5 text-xs text-muted-foreground">{fmtTime(l.ts)}</td>
                    <td className="px-3 py-2.5 font-mono text-xs">{l.file}</td>
                    <td className="px-3 py-2.5 text-xs uppercase">{l.op}</td>
                    <td className="px-3 py-2.5"><ResultPill result={l.result} /></td>
                    <td className="max-w-[320px] truncate px-3 py-2.5 text-xs text-muted-foreground">{l.reason}</td>
                    <td className="px-3 py-2.5 text-xs">{l.process ?? "—"}<div className="text-muted-foreground">{l.user ?? "—"}</div></td>
                    <td className="px-3 py-2.5"><Pill tone="warning" className="text-[10px]">DEMO</Pill></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        {detail && (
          <aside className="h-fit rounded-xl border border-border bg-card p-4 text-sm">
            <div className="mb-3 flex items-center justify-between"><span className="font-medium">Event detail</span><button aria-label="Close" onClick={() => setSel(null)}><X className="h-4 w-4" /></button></div>
            <dl className="space-y-2.5 text-xs">
              {([["ID", detail.id], ["Timestamp", fmtTime(detail.ts)], ["Type", detail.kind], ["File", detail.file], ["Path", detail.path], ["Operation", detail.op], ["Rule", detail.rule], ["User", detail.user], ["Process", detail.process], ["Protection", detail.protection == null ? undefined : detail.protection ? "Enabled" : "Disabled"]] as const).map(([k, v]) => (
                <div key={k} className="grid grid-cols-[6rem_1fr] gap-2"><dt className="text-muted-foreground">{k}</dt><dd className="break-all font-mono">{v ?? "Not available"}</dd></div>
              ))}
              {detail.bits && <div className="grid grid-cols-[6rem_1fr] gap-2"><dt className="text-muted-foreground">Bits</dt><dd><Bits bits={detail.bits} /></dd></div>}
              <div className="grid grid-cols-[6rem_1fr] gap-2"><dt className="text-muted-foreground">Result</dt><dd><ResultPill result={detail.result} /></dd></div>
              <div><dt className="text-muted-foreground">Reason</dt><dd className="mt-1">{detail.reason}</dd></div>
              {detail.details && <div><dt className="text-muted-foreground">Risk indicators</dt><dd className="mt-1">{detail.details}</dd></div>}
            </dl>
            <p className="mt-4 rounded-md bg-warning/10 p-2 text-xs text-warning">Simulated event — not from a real system.</p>
            {detail.result === "denied" && <Link to="/investigate" search={{ id: detail.id }}><Btn className="mt-3 w-full">Investigate</Btn></Link>}
          </aside>
        )}
      </div>
    </>
  );
}
