import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { AlertTriangle, RotateCcw } from "lucide-react";
import { Btn, PageHeader, Panel, Pill } from "@/components/eg/ui";
import { actions, useStore } from "@/lib/execguard/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Protection Settings — ExecGuard" },
      { name: "description", content: "Toggle demo executable write protection and learn about W^X and real Linux enforcement." },
      { property: "og:title", content: "Protection Settings — ExecGuard" },
      { property: "og:description", content: "Toggle demo executable write protection and learn about W^X and real Linux enforcement." },
    ],
  }),
  component: Settings,
});

function Settings() {
  const on = useStore((s) => s.protection);
  return (
    <>
      <PageHeader title="Protection Settings" desc="Control the simulated policy used throughout the app." />
      <div className="mb-6 flex gap-3 rounded-xl border border-warning/40 bg-warning/10 p-4 text-sm">
        <AlertTriangle className="h-5 w-5 shrink-0 text-warning" />
        <div><div className="font-medium text-warning">This web prototype does not enforce operating-system permissions.</div><p className="mt-1 text-muted-foreground">Toggling protection only changes how the in-browser simulator evaluates sample files. No real files, processes or kernel settings are affected.</p></div>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Demo protection">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-sm font-medium">Deny writes to executables (WX-001)</div>
              <p className="mt-1 text-xs text-muted-foreground">When on, any Write to a file with an execute bit is denied regardless of its write bit.</p>
            </div>
            <button role="switch" aria-checked={on} aria-label="Toggle demo protection" onClick={() => { actions.setProtection(!on); toast(on ? "Demo protection disabled" : "Demo protection enabled"); }} className={cn("relative h-6 w-11 shrink-0 rounded-full transition-colors", on ? "bg-success" : "bg-muted")}>
              <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-foreground transition-all", on ? "left-[22px]" : "left-0.5")} />
            </button>
          </div>
          <div className="mt-4 flex items-center gap-2"><Pill tone={on ? "allowed" : "denied"}>{on ? "ENABLED" : "DISABLED"}</Pill><Pill tone="warning">DEMO</Pill></div>
          <div className="mt-6 border-t border-border pt-4">
            <Btn variant="outline" onClick={() => { if (confirm("Reset settings and restore sample audit logs?")) { actions.resetDemo(); toast.success("Demo data reset"); } }}><RotateCcw className="h-4 w-4" />Reset demo data</Btn>
          </div>
        </Panel>
        <Panel title="The W^X principle">
          <div className="space-y-3 text-sm text-muted-foreground">
            <p><b className="text-foreground">Write XOR Execute</b> means a region of memory or a file should be either writable or executable — never both at the same time.</p>
            <p>If attackers can write to something that will later be executed, they can inject code. Denying writes to executables closes that path: binaries are replaced through controlled builds, not patched in place.</p>
          </div>
        </Panel>
        <Panel title="Simulated policy vs real Linux enforcement" className="lg:col-span-2">
          <div className="grid gap-4 text-sm md:grid-cols-2">
            <div className="rounded-lg border border-border p-4">
              <div className="mb-2 font-medium">This prototype (simulated)</div>
              <ul className="list-disc space-y-1 pl-5 text-muted-foreground">
                <li>Runs in the browser with sample file metadata.</li>
                <li>Rules are plain TypeScript functions you can read.</li>
                <li>Logs are stored in browser local storage.</li>
                <li>Cannot stop any real process from writing.</li>
              </ul>
            </div>
            <div className="rounded-lg border border-border p-4">
              <div className="mb-2 font-medium">Real Linux enforcement</div>
              <ul className="list-disc space-y-1 pl-5 text-muted-foreground">
                <li>The kernel returns <code className="font-mono">ETXTBSY</code> when writing to a running executable.</li>
                <li>Permission bits are checked by the VFS on every <code className="font-mono">open()</code>.</li>
                <li>LSMs (SELinux, AppArmor), IMA and <code className="font-mono">noexec</code> mounts add policy.</li>
                <li>Memory W^X is enforced via page protections and <code className="font-mono">mprotect</code>.</li>
              </ul>
            </div>
          </div>
        </Panel>
      </div>
    </>
  );
}
