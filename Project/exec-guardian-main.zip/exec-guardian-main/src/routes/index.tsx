import { createFileRoute, Link } from "@tanstack/react-router";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Activity, FileCode2, Files, GitCompare, ShieldAlert, ShieldCheck } from "lucide-react";
import { Btn, PageHeader, Panel, Pill, ResultPill } from "@/components/eg/ui";
import { SAMPLE_FILES } from "@/lib/execguard/data";
import { isExecutable } from "@/lib/execguard/rules";
import { useStore } from "@/lib/execguard/store";
import { fmtTime } from "@/lib/execguard/format";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — ExecGuard" },
      { name: "description", content: "Overview of executable protection decisions, denials and detected code changes." },
      { property: "og:title", content: "Dashboard — ExecGuard" },
      { property: "og:description", content: "Overview of executable protection decisions, denials and detected code changes." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const logs = useStore((s) => s.logs);
  const protection = useStore((s) => s.protection);
  const access = logs.filter((l) => l.kind === "access");
  const allowed = access.filter((l) => l.result === "allowed").length;
  const denied = access.filter((l) => l.result === "denied").length;
  const changes = logs.filter((l) => l.kind === "compare").length;
  const execCount = SAMPLE_FILES.filter(isExecutable).length;

  const chart = (["read", "write", "execute"] as const).map((op) => ({
    op: op.charAt(0).toUpperCase() + op.slice(1),
    Allowed: access.filter((l) => l.op === op && l.result === "allowed").length,
    Denied: access.filter((l) => l.op === op && l.result === "denied").length,
  }));

  const cards = [
    { label: "Total files", value: SAMPLE_FILES.length, icon: Files, tone: "text-foreground" },
    { label: "Executable files", value: execCount, icon: FileCode2, tone: "text-warning" },
    { label: "Allowed operations", value: allowed, icon: ShieldCheck, tone: "text-success" },
    { label: "Denied operations", value: denied, icon: ShieldAlert, tone: "text-danger" },
    { label: "Detected changes", value: changes, icon: GitCompare, tone: "text-info" },
  ];

  return (
    <>
      <PageHeader
        title="Security overview"
        desc="Simulated executable write protection for the sample file set. All figures come from demo data and your local simulations."
        actions={<Link to="/simulator"><Btn>Run a permission check</Btn></Link>}
      />
      <div className={`mb-6 flex flex-wrap items-center gap-3 rounded-xl border p-4 ${protection ? "border-success/30 bg-success/5" : "border-danger/30 bg-danger/5"}`}>
        {protection ? <ShieldCheck className="h-5 w-5 text-success" /> : <ShieldAlert className="h-5 w-5 text-danger" />}
        <div className="flex-1">
          <div className="text-sm font-medium">Executable write protection is {protection ? "enabled" : "disabled"}</div>
          <div className="text-xs text-muted-foreground">Rule WX-001 {protection ? "denies" : "is not denying"} writes to files with an execute bit.</div>
        </div>
        <Pill tone="warning">DEMO MODE — not OS enforced</Pill>
        <Link to="/settings" className="text-xs text-primary hover:underline">Settings</Link>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5">
        {cards.map((c) => (
          <div key={c.label} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between text-xs text-muted-foreground">{c.label}<c.icon className={`h-4 w-4 ${c.tone}`} /></div>
            <div className="mt-2 text-3xl font-semibold tabular-nums">{c.value}</div>
          </div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Panel title="Operation decisions" className="lg:col-span-2">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="op" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis allowDecimals={false} stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} width={24} />
                <Tooltip cursor={{ fill: "var(--accent)" }} contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="Allowed" fill="var(--success)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Denied" fill="var(--danger)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
        <Panel title={<span className="flex items-center gap-2"><Activity className="h-4 w-4" />Recent access activity</span>} className="lg:col-span-3" actions={<Link to="/logs" className="text-xs text-primary hover:underline">View all</Link>}>
          {access.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">No activity yet. Run a check in the simulator.</p>
          ) : (
            <ul className="divide-y divide-border">
              {access.slice(0, 6).map((l) => (
                <li key={l.id} className="flex items-center gap-3 py-2.5 text-sm">
                  <ResultPill result={l.result} />
                  <span className="font-mono text-xs">{l.file}</span>
                  <span className="text-xs uppercase text-muted-foreground">{l.op}</span>
                  <span className="hidden flex-1 truncate text-xs text-muted-foreground md:block">{l.reason}</span>
                  <span className="ml-auto shrink-0 text-xs text-muted-foreground">{fmtTime(l.ts)}</span>
                  {l.result === "denied" && <Link to="/investigate" search={{ id: l.id }} className="text-xs text-primary hover:underline">Why?</Link>}
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </>
  );
}
