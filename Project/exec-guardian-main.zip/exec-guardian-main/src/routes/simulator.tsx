import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Play, ShieldAlert, ShieldCheck } from "lucide-react";
import { Bits, Btn, PageHeader, Panel, Pill } from "@/components/eg/ui";
import { DEMO_USER, SAMPLE_FILES } from "@/lib/execguard/data";
import { checkAccess, effectivePerm, isExecutable, modeString, RULES } from "@/lib/execguard/rules";
import { actions, useStore } from "@/lib/execguard/store";
import type { CheckResult, LogEntry, Operation } from "@/lib/execguard/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/simulator")({
  validateSearch: (s: Record<string, unknown>): { file?: string | undefined } => ({ file: typeof s["file"] === "string" ? (s["file"] as string) : undefined }),
  head: () => ({
    meta: [
      { title: "Access Simulator — ExecGuard" },
      { name: "description", content: "Run simulated read, write and execute permission checks against sample files." },
      { property: "og:title", content: "Access Simulator — ExecGuard" },
      { property: "og:description", content: "Run simulated read, write and execute permission checks against sample files." },
    ],
  }),
  component: Simulator,
});

const PROCS: Record<Operation, string> = { read: "cat", write: "editor", execute: "shell" };

function Simulator() {
  const search = Route.useSearch();
  const protection = useStore((s) => s.protection);
  const [fileId, setFileId] = useState(search.file ?? "");
  const [op, setOp] = useState<Operation | "">("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ r: CheckResult; log: LogEntry } | null>(null);
  const [error, setError] = useState("");
  const file = SAMPLE_FILES.find((f) => f.id === fileId);

  const run = () => {
    if (!file || !op) {
      setError(!file && !op ? "Select a file and an operation." : !file ? "Select a file." : "Select an operation.");
      return;
    }
    setError("");
    setBusy(true);
    setTimeout(() => {
      const r = checkAccess(file, op, protection);
      const log = actions.log({ kind: "access", file: file.name, path: file.path, op, result: r.decision, rule: r.rule, reason: r.reason, bits: r.bits, protection, user: DEMO_USER, process: `${PROCS[op]} (simulated pid ${1000 + Math.floor(Math.random() * 8999)})` });
      setResult({ r, log });
      setBusy(false);
      (r.decision === "allowed" ? toast.success : toast.error)(`${op.toUpperCase()} ${r.decision} — ${file.name}`, { description: r.ruleName });
    }, 450);
  };

  return (
    <>
      <PageHeader title="Access Simulator" desc="Choose a sample file and operation. The check runs entirely in your browser against demo rules — no code is executed and no real files are touched." />
      <div className="grid gap-4 lg:grid-cols-5">
        <div className="space-y-4 lg:col-span-2">
          <Panel title="1. Select file">
            <div className="grid gap-1.5">
              {SAMPLE_FILES.map((f) => (
                <button key={f.id} onClick={() => { setFileId(f.id); setResult(null); }} className={cn("flex items-center justify-between rounded-md border px-3 py-2 text-left transition-colors", fileId === f.id ? "border-primary/50 bg-primary/10" : "border-border hover:bg-accent")}>
                  <span><span className="font-mono text-xs font-medium">{f.name}</span><span className="ml-2 text-xs text-muted-foreground">{f.owner}</span></span>
                  <span className="flex items-center gap-2">{isExecutable(f) && <Pill tone="warning">exec</Pill>}<Bits bits={modeString(f)} /></span>
                </button>
              ))}
            </div>
          </Panel>
          <Panel title="2. Select operation">
            <div className="grid grid-cols-3 gap-2">
              {(["read", "write", "execute"] as const).map((o) => (
                <button key={o} onClick={() => { setOp(o); setResult(null); }} className={cn("rounded-md border py-2.5 text-sm capitalize", op === o ? "border-primary/50 bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:bg-accent")}>{o}</button>
              ))}
            </div>
            {error && <p className="mt-3 text-xs text-danger">{error}</p>}
            <Btn className="mt-4 w-full" onClick={run} disabled={busy}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}Run Permission Check</Btn>
            <p className="mt-2 text-center text-xs text-muted-foreground">Acting as <span className="font-mono">{DEMO_USER}</span> · Protection {protection ? "ON" : "OFF"}</p>
          </Panel>
        </div>

        <div className="space-y-4 lg:col-span-3">
          {busy ? (
            <Panel><div className="flex h-64 items-center justify-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" />Evaluating policy…</div></Panel>
          ) : !result || !file ? (
            <Panel><div className="flex h-64 flex-col items-center justify-center text-center text-sm text-muted-foreground"><ShieldCheck className="mb-3 h-8 w-8 opacity-40" />Select a file and operation, then run a check to see the decision.</div></Panel>
          ) : (
            <ResultView r={result.r} log={result.log} />
          )}
          <Panel title="Demo rules (evaluated in order)">
            <ol className="space-y-2 text-xs">
              <li className="flex gap-2"><span className="font-mono text-warning">WX-001</span><span className="text-muted-foreground">If protection is enabled and the file has any execute bit → deny <b>Write</b>.</span></li>
              <li className="flex gap-2"><span className="font-mono text-info">PERM-W</span><span className="text-muted-foreground">Write requires the w bit for the applicable class (owner if user owns the file, otherwise other).</span></li>
              <li className="flex gap-2"><span className="font-mono text-info">PERM-R</span><span className="text-muted-foreground">Read requires the r bit.</span></li>
              <li className="flex gap-2"><span className="font-mono text-info">PERM-X</span><span className="text-muted-foreground">Execute requires the x bit.</span></li>
            </ol>
          </Panel>
        </div>
      </div>
    </>
  );
}

function ResultView({ r, log }: { r: CheckResult; log: LogEntry }) {
  const f = SAMPLE_FILES.find((x) => x.name === log.file)!;
  const { cls } = effectivePerm(f);
  const ok = r.decision === "allowed";
  return (
    <section className={cn("rounded-xl border p-5", ok ? "border-success/30 bg-success/5" : "border-danger/30 bg-danger/5")}>
      <div className="flex items-center gap-3">
        {ok ? <ShieldCheck className="h-7 w-7 text-success" /> : <ShieldAlert className="h-7 w-7 text-danger" />}
        <div>
          <div className={cn("text-xl font-semibold", ok ? "text-success" : "text-danger")}>{log.op.toUpperCase()} {ok ? "ALLOWED" : "DENIED"}</div>
          <div className="font-mono text-xs text-muted-foreground">{f.path}</div>
        </div>
        <Pill tone="warning" className="ml-auto">SIMULATED</Pill>
      </div>
      <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-2">
        <div className="sm:col-span-2"><dt className="text-xs text-muted-foreground">Exact reason</dt><dd className="mt-1">{r.reason}</dd></div>
        <div><dt className="text-xs text-muted-foreground">Applicable rule</dt><dd className="mt-1"><span className="font-mono">{r.rule}</span> — {RULES[r.rule]}</dd></div>
        <div><dt className="text-xs text-muted-foreground">Permission bits ({cls} class applies)</dt><dd className="mt-1"><Bits bits={r.bits} /></dd></div>
        <div className="sm:col-span-2"><dt className="text-xs text-muted-foreground">Recommended next step</dt><dd className="mt-1">{r.nextStep}</dd></div>
      </dl>
      <div className="mt-5 flex flex-wrap gap-2">
        {!ok && <Link to="/investigate" search={{ id: log.id }}><Btn>Investigate denial</Btn></Link>}
        <Link to="/logs" search={{ q: f.name }}><Btn variant="outline">View in audit log</Btn></Link>
      </div>
    </section>
  );
}
