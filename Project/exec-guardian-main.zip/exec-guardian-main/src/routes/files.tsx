import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Check, Minus } from "lucide-react";
import { Bits, Btn, Empty, inputCls, PageHeader, Panel, Pill } from "@/components/eg/ui";
import { SAMPLE_FILES } from "@/lib/execguard/data";
import { checkAccess, effectivePerm, isExecutable, modeString, octal } from "@/lib/execguard/rules";
import { useStore } from "@/lib/execguard/store";
import { fmtSize, fmtTime } from "@/lib/execguard/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/files")({
  head: () => ({
    meta: [
      { title: "File Explorer — ExecGuard" },
      { name: "description", content: "Browse sample files, permission bits and write status under the demo policy." },
      { property: "og:title", content: "File Explorer — ExecGuard" },
      { property: "og:description", content: "Browse sample files, permission bits and write status under the demo policy." },
    ],
  }),
  component: FilesPage,
});

const FILTERS = ["all", "executable", "non-executable", "allowed", "denied"] as const;

function FilesPage() {
  const protection = useStore((s) => s.protection);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all");
  const [sel, setSel] = useState<string | null>("f1");

  const rows = useMemo(() => {
    return SAMPLE_FILES.map((f) => ({ f, write: checkAccess(f, "write", protection) })).filter(({ f, write }) => {
      if (q && !`${f.name} ${f.path} ${f.type} ${f.owner}`.toLowerCase().includes(q.toLowerCase())) return false;
      if (filter === "executable") return isExecutable(f);
      if (filter === "non-executable") return !isExecutable(f);
      if (filter === "allowed") return write.decision === "allowed";
      if (filter === "denied") return write.decision === "denied";
      return true;
    });
  }, [q, filter, protection]);

  const file = SAMPLE_FILES.find((f) => f.id === sel);

  return (
    <>
      <PageHeader title="File Explorer" desc="Sample file set. 'Allowed' / 'Denied' filters reflect whether a write by user 'student' would pass the current demo policy." />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <input className={cn(inputCls, "w-full sm:w-72")} placeholder="Search name, path, type, owner…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="flex flex-wrap gap-1 rounded-lg border border-border p-1">
          {FILTERS.map((x) => (
            <button key={x} onClick={() => setFilter(x)} className={cn("rounded-md px-2.5 py-1 text-xs capitalize", filter === x ? "bg-accent text-foreground" : "text-muted-foreground hover:text-foreground")}>{x === "allowed" ? "Write allowed" : x === "denied" ? "Write denied" : x}</button>
          ))}
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <div className="overflow-x-auto rounded-xl border border-border bg-card xl:col-span-2">
          {rows.length === 0 ? (
            <div className="p-4"><Empty title="No files match" desc="Try a different search or filter."><Btn variant="outline" onClick={() => { setQ(""); setFilter("all"); }}>Clear filters</Btn></Empty></div>
          ) : (
            <table className="w-full min-w-[820px] text-sm">
              <thead className="border-b border-border text-left text-xs text-muted-foreground">
                <tr>{["Name", "Path", "Type", "Exec", "Read", "Write", "Owner", "Modified", "Write status"].map((h) => <th key={h} className="px-3 py-2.5 font-medium">{h}</th>)}</tr>
              </thead>
              <tbody>
                {rows.map(({ f, write }) => {
                  const { perm } = effectivePerm(f);
                  return (
                    <tr key={f.id} onClick={() => setSel(f.id)} className={cn("cursor-pointer border-b border-border/60 last:border-0 hover:bg-accent/50", sel === f.id && "bg-accent")}>
                      <td className="px-3 py-2.5 font-mono text-xs font-medium">{f.name}</td>
                      <td className="max-w-[180px] truncate px-3 py-2.5 font-mono text-xs text-muted-foreground">{f.path}</td>
                      <td className="px-3 py-2.5 text-xs">{f.type}</td>
                      <td className="px-3 py-2.5">{isExecutable(f) ? <Pill tone="warning">exec</Pill> : <Minus className="h-3 w-3 text-muted-foreground" />}</td>
                      <td className="px-3 py-2.5"><Flag on={perm.r} /></td>
                      <td className="px-3 py-2.5"><Flag on={perm.w} /></td>
                      <td className="px-3 py-2.5 text-xs">{f.owner}</td>
                      <td className="whitespace-nowrap px-3 py-2.5 text-xs text-muted-foreground">{fmtTime(f.modified)}</td>
                      <td className="px-3 py-2.5"><Pill tone={write.decision}>{write.decision}</Pill></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        <Panel title="File inspector">
          {!file ? (
            <Empty title="No file selected" desc="Select a row to inspect its properties." />
          ) : (
            <div className="space-y-4 text-sm">
              <div>
                <div className="font-mono text-base font-semibold">{file.name}</div>
                <div className="break-all font-mono text-xs text-muted-foreground">{file.path}</div>
              </div>
              <dl className="grid grid-cols-2 gap-2 text-xs">
                {[["Type", file.type], ["Size", fmtSize(file.size)], ["Owner", file.owner], ["Group", file.group], ["Octal", octal(file)], ["Modified", fmtTime(file.modified)]].map(([k, v]) => (
                  <div key={k} className="rounded-md bg-muted/50 p-2"><dt className="text-muted-foreground">{k}</dt><dd className="mt-0.5 font-mono">{v}</dd></div>
                ))}
              </dl>
              <div>
                <div className="mb-2 text-xs text-muted-foreground">Permission bits · <Bits bits={modeString(file)} /></div>
                <table className="w-full text-center text-xs">
                  <thead className="text-muted-foreground"><tr><th className="text-left font-normal">Class</th><th className="font-normal">r</th><th className="font-normal">w</th><th className="font-normal">x</th></tr></thead>
                  <tbody>
                    {(["owner", "group", "other"] as const).map((c) => (
                      <tr key={c} className="border-t border-border/60"><td className="py-1.5 text-left capitalize">{c}</td><td><Flag on={file.mode[c].r} /></td><td><Flag on={file.mode[c].w} /></td><td><Flag on={file.mode[c].x} /></td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="space-y-1.5">
                {(["read", "write", "execute"] as const).map((op) => {
                  const r = checkAccess(file, op, protection);
                  return <div key={op} className="flex items-center justify-between rounded-md border border-border px-2.5 py-1.5 text-xs"><span className="capitalize">{op}</span><span className="flex items-center gap-2 text-muted-foreground">{r.rule}<Pill tone={r.decision}>{r.decision}</Pill></span></div>;
                })}
              </div>
              <Link to="/simulator" search={{ file: file.id }}><Btn className="w-full">Simulate access</Btn></Link>
            </div>
          )}
        </Panel>
      </div>
    </>
  );
}

function Flag({ on }: { on: boolean }) {
  return on ? <Check className="mx-auto inline h-3.5 w-3.5 text-success" /> : <Minus className="mx-auto inline h-3.5 w-3.5 text-muted-foreground/50" />;
}
