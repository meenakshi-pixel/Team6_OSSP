import type { LogEntry } from "./types";

export const fmtTime = (iso: string) =>
  new Date(iso).toLocaleString(undefined, { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });

export const fmtSize = (b: number) => (b > 1024 * 1024 ? `${(b / 1048576).toFixed(1)} MB` : b > 1024 ? `${(b / 1024).toFixed(1)} KB` : `${b} B`);

const esc = (v: unknown) => {
  const s = v == null ? "" : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function logsToCsv(logs: LogEntry[]) {
  const cols: (keyof LogEntry)[] = ["ts", "kind", "file", "path", "op", "result", "rule", "reason", "process", "user", "bits", "protection", "demo"];
  return [cols.join(","), ...logs.map((l) => cols.map((c) => esc(l[c])).join(","))].join("\n");
}

export function downloadText(name: string, text: string, mime = "text/csv") {
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}
