import { DEMO_USER } from "./data";
import type { CheckResult, Operation, Perm, SampleFile } from "./types";

export const permString = (p: Perm) => `${p.r ? "r" : "-"}${p.w ? "w" : "-"}${p.x ? "x" : "-"}`;
export const modeString = (f: SampleFile) =>
  permString(f.mode.owner) + permString(f.mode.group) + permString(f.mode.other);
export const octal = (f: SampleFile) =>
  [f.mode.owner, f.mode.group, f.mode.other]
    .map((p) => (p.r ? 4 : 0) + (p.w ? 2 : 0) + (p.x ? 1 : 0))
    .join("");

/** Which permission class applies to the demo user. Simplified: owner or other. */
export function effectivePerm(f: SampleFile, user = DEMO_USER): { cls: "owner" | "other"; perm: Perm } {
  return f.owner === user ? { cls: "owner", perm: f.mode.owner } : { cls: "other", perm: f.mode.other };
}

/** A file is "executable" if any class has the execute bit. */
export const isExecutable = (f: SampleFile) => f.mode.owner.x || f.mode.group.x || f.mode.other.x;

export const RULES = {
  "WX-001": "Executable write protection (W^X)",
  "PERM-W": "Write permission required",
  "PERM-R": "Read permission required",
  "PERM-X": "Execute permission required",
  ALLOW: "Permitted by permission bits",
} as const;

/**
 * Transparent demo policy. Pure function — easy to swap for a real Linux service later.
 * Order: W^X protection first, then standard permission bits.
 */
export function checkAccess(f: SampleFile, op: Operation, protection: boolean, user = DEMO_USER): CheckResult {
  const { cls, perm } = effectivePerm(f, user);
  const bits = modeString(f);
  const who = cls === "owner" ? "owner" : "'other'";

  if (op === "write") {
    if (protection && isExecutable(f)) {
      return {
        decision: "denied",
        rule: "WX-001",
        ruleName: RULES["WX-001"],
        reason: `Executable protection policy: ${f.name} has an execute bit set (${bits}). While protection is enabled, writes to executables are denied, even though the ${who} class ${perm.w ? "has" : "lacks"} write permission.`,
        bits,
        nextStep: "Rebuild the executable from verified source, or remove the execute bit (chmod a-x) through an approved change process before editing.",
      };
    }
    if (perm.w) {
      return { decision: "allowed", rule: "ALLOW", ruleName: RULES.ALLOW, reason: `${f.name} is ${isExecutable(f) ? "executable but protection is disabled" : "non-executable"} and the ${who} class has write permission (w).`, bits, nextStep: "No action needed. The write would proceed." };
    }
    return {
      decision: "denied",
      rule: "PERM-W",
      ruleName: RULES["PERM-W"],
      reason: `Missing write permission: the ${who} class has no write bit (${permString(perm)}).${cls === "other" ? ` User '${user}' does not own this file (owner: ${f.owner}).` : ""}`,
      bits,
      nextStep: cls === "owner" ? "Grant write permission (chmod u+w) if the change is intended." : `Ask the owner (${f.owner}) or an administrator for access.`,
    };
  }

  const need = op === "read" ? perm.r : perm.x;
  const rule = op === "read" ? "PERM-R" : "PERM-X";
  if (need) {
    return { decision: "allowed", rule: "ALLOW", ruleName: RULES.ALLOW, reason: `The ${who} class has the ${op} bit (${op === "read" ? "r" : "x"}) set.`, bits, nextStep: "No action needed." };
  }
  return {
    decision: "denied",
    rule,
    ruleName: RULES[rule],
    reason: `Insufficient access rights: the ${who} class lacks the ${op} bit (${permString(perm)}).${cls === "other" ? ` File is owned by ${f.owner}.` : ""}`,
    bits,
    nextStep: op === "read" ? "Request read access from the file owner." : "Confirm the file is meant to be executable before adding the execute bit.",
  };
}
