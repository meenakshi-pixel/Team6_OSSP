import { useSyncExternalStore } from "react";
import { SEED_LOGS } from "./data";
import type { LogEntry } from "./types";

interface State {
  protection: boolean;
  logs: LogEntry[];
  readNotifications: string[];
}

const KEY = "execguard:v1";
const DEFAULT: State = { protection: true, logs: SEED_LOGS, readNotifications: [] };

let state: State = DEFAULT;
let loaded = false;
const listeners = new Set<() => void>();

function load() {
  if (loaded || typeof window === "undefined") return;
  loaded = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) state = { ...DEFAULT, ...JSON.parse(raw) };
  } catch {
    /* ignore corrupt storage */
  }
}

function set(patch: Partial<State> | ((s: State) => Partial<State>)) {
  load();
  state = { ...state, ...(typeof patch === "function" ? patch(state) : patch) };
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* quota */
  }
  listeners.forEach((l) => l());
}

export function useStore<T>(sel: (s: State) => T): T {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => {
      load();
      return sel(state);
    },
    () => sel(DEFAULT),
  );
}

export const actions = {
  setProtection(on: boolean) {
    set({ protection: on });
    actions.log({ kind: "settings", file: "—", op: "policy", result: "info", reason: `Demo protection ${on ? "enabled" : "disabled"}.`, user: "student" });
  },
  log(e: Omit<LogEntry, "id" | "ts" | "demo">) {
    const entry: LogEntry = { ...e, id: crypto.randomUUID(), ts: new Date().toISOString(), demo: true };
    set((s) => ({ logs: [entry, ...s.logs].slice(0, 500) }));
    return entry;
  },
  clearLogs() {
    set({ logs: [] });
  },
  resetDemo() {
    set({ ...DEFAULT });
  },
  markAllRead(ids: string[]) {
    set({ readNotifications: ids });
  },
};
