import type { LogEntry, Perm, SampleFile } from "./types";

const p = (s: string): Perm => ({ r: s[0] === "r", w: s[1] === "w", x: s[2] === "x" });
const mode = (m: string) => ({ owner: p(m.slice(0, 3)), group: p(m.slice(3, 6)), other: p(m.slice(6, 9)) });

/** Demo user that the simulator acts as. Owner perms apply when user owns the file. */
export const DEMO_USER = "student";

export const SAMPLE_FILES: SampleFile[] = [
  { id: "f1", name: "app.bin", path: "/opt/execguard/bin/app.bin", type: "ELF binary", owner: "student", group: "dev", size: 482304, modified: "2026-10-09T14:22:00Z", mode: mode("rwxr-xr-x") },
  { id: "f2", name: "script.sh", path: "/home/student/scripts/script.sh", type: "Shell script", owner: "student", group: "dev", size: 2140, modified: "2026-10-10T09:05:00Z", mode: mode("rwxr-x---") },
  { id: "f3", name: "config.json", path: "/home/student/app/config.json", type: "JSON config", owner: "student", group: "dev", size: 812, modified: "2026-10-10T18:40:00Z", mode: mode("rw-r--r--") },
  { id: "f4", name: "main.c", path: "/home/student/src/main.c", type: "C source", owner: "student", group: "dev", size: 6930, modified: "2026-10-08T11:12:00Z", mode: mode("rw-r--r--") },
  { id: "f5", name: "library.so", path: "/usr/local/lib/library.so", type: "Shared object", owner: "root", group: "root", size: 131072, modified: "2026-09-30T07:00:00Z", mode: mode("rwxr-xr-x") },
  { id: "f6", name: "README.md", path: "/home/student/app/README.md", type: "Markdown", owner: "student", group: "dev", size: 1520, modified: "2026-10-07T16:30:00Z", mode: mode("rw-rw-r--") },
  { id: "f7", name: "shadow.bak", path: "/etc/shadow.bak", type: "System file", owner: "root", group: "shadow", size: 1204, modified: "2026-09-12T03:00:00Z", mode: mode("rw-------") },
  { id: "f8", name: "report.txt", path: "/home/student/docs/report.txt", type: "Text", owner: "student", group: "dev", size: 4410, modified: "2026-10-06T10:00:00Z", mode: mode("r--r--r--") },
  { id: "f9", name: "deploy.py", path: "/home/student/scripts/deploy.py", type: "Python script", owner: "student", group: "dev", size: 3290, modified: "2026-10-10T20:15:00Z", mode: mode("rwxrwxr-x") },
  { id: "f10", name: "kernel-mod.ko", path: "/lib/modules/kernel-mod.ko", type: "Kernel module", owner: "root", group: "root", size: 90112, modified: "2026-09-28T12:00:00Z", mode: mode("rw-r--r--") },
];

const ago = (min: number) => new Date(Date.UTC(2026, 9, 11, 5, 0) - min * 60000).toISOString();

export const SEED_LOGS: LogEntry[] = [
  { id: "seed-1", ts: ago(12), kind: "access", file: "app.bin", path: "/opt/execguard/bin/app.bin", op: "write", result: "denied", rule: "WX-001", reason: "Executable protection policy: file has execute bit set; writes are denied while protection is enabled.", process: "vim (pid 4121)", user: "student", protection: true, bits: "rwxr-xr-x", demo: true },
  { id: "seed-2", ts: ago(30), kind: "access", file: "config.json", path: "/home/student/app/config.json", op: "write", result: "allowed", rule: "ALLOW", reason: "Non-executable file with owner write permission.", process: "nano (pid 3880)", user: "student", protection: true, bits: "rw-r--r--", demo: true },
  { id: "seed-3", ts: ago(47), kind: "access", file: "report.txt", path: "/home/student/docs/report.txt", op: "write", result: "denied", rule: "PERM-W", reason: "Missing write permission: owner write bit (w) is not set.", process: "echo (pid 3512)", user: "student", protection: true, bits: "r--r--r--", demo: true },
  { id: "seed-4", ts: ago(65), kind: "access", file: "library.so", path: "/usr/local/lib/library.so", op: "execute", result: "allowed", rule: "ALLOW", reason: "Execute bit set for 'other' class.", process: "ld.so (pid 3301)", user: "student", protection: true, bits: "rwxr-xr-x", demo: true },
  { id: "seed-5", ts: ago(90), kind: "access", file: "shadow.bak", path: "/etc/shadow.bak", op: "read", result: "denied", rule: "PERM-R", reason: "Insufficient access rights: user is not owner and 'other' class has no read bit.", process: "cat (pid 2990)", user: "student", protection: true, bits: "rw-------", demo: true },
  { id: "seed-6", ts: ago(120), kind: "compare", file: "main.c", op: "compare", result: "changed", reason: "Sample comparison: 3 added, 1 removed, 1 changed line(s).", user: "student", demo: true },
  { id: "seed-7", ts: ago(150), kind: "access", file: "script.sh", path: "/home/student/scripts/script.sh", op: "write", result: "denied", rule: "WX-001", reason: "Executable protection policy: file has execute bit set; writes are denied while protection is enabled.", process: "sed (pid 2701)", user: "student", protection: true, bits: "rwxr-x---", demo: true },
  { id: "seed-8", ts: ago(200), kind: "access", file: "main.c", path: "/home/student/src/main.c", op: "read", result: "allowed", rule: "ALLOW", reason: "Owner read bit set.", process: "gcc (pid 2410)", user: "student", protection: true, bits: "rw-r--r--", demo: true },
];
