import { describe, expect, it } from "vitest";
import { SAMPLE_FILES } from "./data";
import { checkAccess } from "./rules";

const f = (n: string) => SAMPLE_FILES.find((x) => x.name === n)!;

describe("demo access rules", () => {
  it("denies write to executable when protection is on", () => {
    expect(checkAccess(f("app.bin"), "write", true).rule).toBe("WX-001");
  });
  it("allows write to executable with write bit when protection is off", () => {
    expect(checkAccess(f("app.bin"), "write", false).decision).toBe("allowed");
  });
  it("allows write to non-executable file with write permission", () => {
    expect(checkAccess(f("config.json"), "write", true).decision).toBe("allowed");
  });
  it("denies write when write permission is absent", () => {
    expect(checkAccess(f("report.txt"), "write", true).rule).toBe("PERM-W");
  });
  it("allows execute on executable", () => {
    expect(checkAccess(f("script.sh"), "execute", true).decision).toBe("allowed");
  });
});
