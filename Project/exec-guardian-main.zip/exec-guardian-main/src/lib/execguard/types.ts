export type Operation = "read" | "write" | "execute";
export type Decision = "allowed" | "denied";

export interface Perm {
  r: boolean;
  w: boolean;
  x: boolean;
}

export interface SampleFile {
  id: string;
  name: string;
  path: string;
  type: string;
  owner: string;
  group: string;
  size: number;
  modified: string;
  /** Unix-style permission triplets: owner, group, other */
  mode: { owner: Perm; group: Perm; other: Perm };
}

export type RuleId = "WX-001" | "PERM-W" | "PERM-R" | "PERM-X" | "ALLOW";

export interface CheckResult {
  decision: Decision;
  rule: RuleId;
  ruleName: string;
  reason: string;
  bits: string;
  nextStep: string;
}

export interface LogEntry {
  id: string;
  ts: string;
  kind: "access" | "compare" | "settings";
  file: string;
  path?: string;
  op: string;
  result: Decision | "changed" | "info";
  reason: string;
  rule?: RuleId;
  process?: string;
  user?: string;
  protection?: boolean;
  bits?: string;
  details?: string;
  demo: true;
}
