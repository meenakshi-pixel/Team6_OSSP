import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import type { LogEntry } from "@/lib/execguard/types";

export function PageHeader({ title, desc, actions }: { title: string; desc?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        {desc && <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{desc}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

export function Panel({ title, children, className, actions }: { title?: ReactNode; children: ReactNode; className?: string; actions?: ReactNode }) {
  return (
    <section className={cn("rounded-xl border border-border bg-card", className)}>
      {title && (
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <h2 className="text-sm font-medium">{title}</h2>
          {actions}
        </div>
      )}
      <div className="p-4">{children}</div>
    </section>
  );
}

type Tone = "allowed" | "denied" | "warning" | "neutral" | "info";
const tones: Record<Tone, string> = {
  allowed: "bg-success/12 text-success border-success/30",
  denied: "bg-danger/12 text-danger border-danger/30",
  warning: "bg-warning/12 text-warning border-warning/30",
  info: "bg-info/12 text-info border-info/30",
  neutral: "bg-muted text-muted-foreground border-border",
};

export function Pill({ tone = "neutral", children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return <span className={cn("inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-xs font-medium", tones[tone], className)}>{children}</span>;
}

export function ResultPill({ result }: { result: LogEntry["result"] }) {
  const tone: Tone = result === "allowed" ? "allowed" : result === "denied" ? "denied" : result === "changed" ? "warning" : "info";
  return <Pill tone={tone}>{result.toUpperCase()}</Pill>;
}

export function Btn({ variant = "primary", className, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "outline" | "danger" }) {
  const v = {
    primary: "bg-primary text-primary-foreground hover:bg-primary/90",
    outline: "border border-border bg-transparent hover:bg-accent",
    ghost: "hover:bg-accent",
    danger: "border border-danger/40 text-danger hover:bg-danger/10",
  }[variant];
  return <button {...p} className={cn("inline-flex h-9 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium transition-colors disabled:pointer-events-none disabled:opacity-50", v, className)} />;
}

export function Bits({ bits }: { bits: string }) {
  return (
    <span className="inline-flex font-mono text-xs">
      {bits.split("").map((c, i) => (
        <span key={i} className={cn("w-3.5 text-center", c === "-" ? "text-muted-foreground/50" : c === "x" ? "text-warning" : c === "w" ? "text-info" : "text-foreground", (i === 2 || i === 5) && "mr-1.5")}>{c}</span>
      ))}
    </span>
  );
}

export function Empty({ title, desc, children }: { title: string; desc?: string; children?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-12 text-center">
      <p className="text-sm font-medium">{title}</p>
      {desc && <p className="mt-1 max-w-sm text-xs text-muted-foreground">{desc}</p>}
      {children && <div className="mt-4">{children}</div>}
    </div>
  );
}

export const inputCls = "h-9 rounded-md border border-input bg-background px-3 text-sm outline-none placeholder:text-muted-foreground focus:border-ring focus:ring-2 focus:ring-ring/30";
