import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { Bell, FileSearch, FolderTree, GitCompare, LayoutDashboard, Menu, ScrollText, Search, Settings, ShieldCheck, ShieldOff, TerminalSquare, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { actions, useStore } from "@/lib/execguard/store";
import { fmtTime } from "@/lib/execguard/format";

const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/files", label: "File Explorer", icon: FolderTree },
  { to: "/simulator", label: "Access Simulator", icon: TerminalSquare },
  { to: "/investigate", label: "Why Denied?", icon: FileSearch },
  { to: "/analyzer", label: "Code Change Analyzer", icon: GitCompare },
  { to: "/logs", label: "Audit Logs", icon: ScrollText },
  { to: "/settings", label: "Protection Settings", icon: Settings },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const protection = useStore((s) => s.protection);

  const sidebar = (
    <nav className="flex h-full flex-col gap-1 p-3">
      <Link to="/" className="mb-4 flex items-center gap-2 px-2 py-2" onClick={() => setOpen(false)}>
        <div className="grid h-8 w-8 place-items-center rounded-md bg-primary/15 text-primary"><ShieldCheck className="h-4 w-4" /></div>
        <div>
          <div className="text-sm font-semibold leading-none">ExecGuard</div>
          <div className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">W^X Demo Console</div>
        </div>
      </Link>
      {NAV.map((n) => {
        const active = n.to === "/" ? path === "/" : path.startsWith(n.to);
        return (
          <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className={cn("flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors", active ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-accent/60 hover:text-foreground")}>
            <n.icon className={cn("h-4 w-4", active && "text-primary")} />
            {n.label}
          </Link>
        );
      })}
      <div className="mt-auto rounded-lg border border-warning/30 bg-warning/10 p-3 text-xs text-warning">
        Simulation only. This prototype does not enforce real OS permissions.
      </div>
    </nav>
  );

  return (
    <div className="flex min-h-screen w-full">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 border-r border-border bg-sidebar md:block">{sidebar}</aside>
      {open && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-background/80" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 w-64 border-r border-border bg-sidebar">
            <button aria-label="Close menu" className="absolute right-2 top-3 p-2" onClick={() => setOpen(false)}><X className="h-4 w-4" /></button>
            {sidebar}
          </aside>
        </div>
      )}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-40 flex h-14 items-center gap-3 border-b border-border bg-background/85 px-4 backdrop-blur">
          <button aria-label="Open menu" className="md:hidden" onClick={() => setOpen(true)}><Menu className="h-5 w-5" /></button>
          <TopSearch />
          <div className="ml-auto flex items-center gap-2">
            <Link to="/settings" className={cn("hidden items-center gap-2 rounded-md border px-2.5 py-1 text-xs font-medium sm:flex", protection ? "border-success/30 bg-success/10 text-success" : "border-danger/30 bg-danger/10 text-danger")}>
              {protection ? <ShieldCheck className="h-3.5 w-3.5" /> : <ShieldOff className="h-3.5 w-3.5" />}
              Protection {protection ? "ON" : "OFF"}
              <span className="rounded bg-warning/15 px-1.5 text-[10px] text-warning">DEMO</span>
            </Link>
            <Notifications />
          </div>
        </header>
        <main className="mx-auto w-full max-w-7xl flex-1 p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}

function TopSearch() {
  const nav = useNavigate();
  const [q, setQ] = useState("");
  return (
    <form
      className="relative w-full max-w-sm"
      onSubmit={(e) => {
        e.preventDefault();
        nav({ to: "/logs", search: { q: q.trim() || undefined } });
      }}
    >
      <Search className="pointer-events-none absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search audit logs by file, reason, user…" className="h-9 w-full rounded-md border border-input bg-card pl-8 pr-3 text-sm outline-none focus:border-ring" />
    </form>
  );
}

function Notifications() {
  const logs = useStore((s) => s.logs);
  const read = useStore((s) => s.readNotifications);
  const [open, setOpen] = useState(false);
  const items = logs.filter((l) => l.result === "denied" || l.result === "changed").slice(0, 6);
  const unread = items.filter((i) => !read.includes(i.id)).length;
  return (
    <div className="relative">
      <button aria-label="Notifications" onClick={() => setOpen((o) => !o)} className="relative grid h-9 w-9 place-items-center rounded-md border border-border hover:bg-accent">
        <Bell className="h-4 w-4" />
        {unread > 0 && <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-semibold text-danger-foreground">{unread}</span>}
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-50 mt-2 w-80 rounded-lg border border-border bg-popover shadow-xl">
            <div className="flex items-center justify-between border-b border-border px-3 py-2">
              <span className="text-sm font-medium">Alerts</span>
              <button className="text-xs text-primary hover:underline" onClick={() => actions.markAllRead(items.map((i) => i.id))}>Mark all read</button>
            </div>
            {items.length === 0 ? (
              <p className="p-4 text-center text-xs text-muted-foreground">No alerts.</p>
            ) : (
              <ul className="max-h-80 overflow-auto">
                {items.map((i) => (
                  <li key={i.id}>
                    <Link to={i.result === "denied" ? "/investigate" : "/logs"} search={i.result === "denied" ? { id: i.id } : { q: i.file }} onClick={() => setOpen(false)} className="block border-b border-border/60 px-3 py-2 hover:bg-accent">
                      <div className="flex items-center gap-2 text-xs">
                        <span className={cn("h-1.5 w-1.5 rounded-full", i.result === "denied" ? "bg-danger" : "bg-warning", read.includes(i.id) && "opacity-30")} />
                        <span className="font-mono">{i.file}</span>
                        <span className="text-muted-foreground">· {i.op}</span>
                      </div>
                      <div className="mt-0.5 truncate text-xs text-muted-foreground">{i.reason}</div>
                      <div className="text-[10px] text-muted-foreground/70">{fmtTime(i.ts)}</div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      )}
    </div>
  );
}
