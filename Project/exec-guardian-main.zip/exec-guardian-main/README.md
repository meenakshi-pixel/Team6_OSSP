# Exec Guardian

Build a complete, polished cybersecurity web application called **ExecGuard**, based on my Operating Systems project, “Denying Writes to Executables.”

**Goal:** Create a functional interactive prototype that demonstrates executable file protection, permission decisions, denial reasons, code version comparison, and security audit logs.

**DESIGN**
- Professional cybersecurity SaaS dashboard, not a generic template.
- Dark graphite background, white text, restrained emerald green for allowed operations, amber for warnings, and red for denied operations.
- Modern typography, subtle borders, clean tables, readable code blocks, responsive layout, and polished interactions.
- Left sidebar navigation and a top bar with search, notifications, and a protection status indicator.

**PAGES AND FEATURES**

1. **Dashboard**
   - Summary cards for total files, executable files, allowed operations, denied operations, and detected changes.
   - Recent access activity and an operation decision chart.
   - Protection status clearly marked as Demo Mode.

2. **File Explorer**
   - Display a searchable, filterable table containing file name, path, file type, executable status, read permission, write permission, owner, and last modified time.
   - Include sample files such as `app.bin`, `script.sh`, `config.json`, `main.c`, and `library.so`.
   - Allow selecting a file to inspect its properties and permission bits.
   - Add filters for executable, non-executable, allowed, and denied.

3. **Access Simulator**
   - Let users select a sample file and an operation: Read, Write, or Execute.
   - Add a Run Permission Check button.
   - Apply transparent demo rules: if protection is enabled and a file has an execute bit, deny Write and explain the policy. Allow other operations when permitted by the sample permission rules.
   - If a non-executable file has write permission, allow Write. If write permission is absent, deny it.
   - Show the decision, exact reason, relevant permission bits, applicable rule, and recommended next step.
   - Never execute uploaded code or modify real system files.

4. **Why Was Access Denied?**
   - Create a detailed investigation panel showing the file path, attempted operation, permission state, rule triggered, timestamp, and denial reason.
   - Use example denial reasons such as executable protection policy, missing write permission, or insufficient access rights.
   - Distinguish confirmed facts from possible explanations.

5. **Code Change Analyzer**
   - Provide two code editors labelled Original Version and Modified Version.
   - Include sample C, Python, and shell code.
   - Add a Compare Versions button.
   - Highlight added lines in green, removed lines in red, and changed lines clearly.
   - Summarize what changed and explain possible effects.
   - Do not claim to know who changed code or why without supporting evidence.

6. **Audit Logs**
   - Show timestamp, file, operation, result, reason, and process/user fields when available.
   - Include search, filtering, detail view, and CSV export.
   - Log every access simulation and every detected sample code comparison.
   - Label simulated events clearly as demo data.

7. **Protection Settings**
   - Toggle demo protection on and off.
   - Explain the W^X principle and the difference between a simulated policy and real Linux enforcement.
   - Include a clear warning that the web prototype does not enforce operating-system permissions.

**FUNCTIONAL REQUIREMENTS**
- Use React, TypeScript, Tailwind CSS, and reusable components.
- Implement all interactions with working frontend logic and local demo data.
- Persist demo settings and logs in browser local storage.
- Include realistic sample records, loading states, empty states, notifications, and validation.
- All sidebar links, buttons, filters, file selection, permission checks, comparison actions, and CSV exports must work.
- Do not use fake buttons, placeholder pages, paid APIs, or external AI integrations.
- Do not create a backend unless explicitly requested later.
- Keep the code organized, reliable, and easy to extend with a future Linux security service.

Build the complete application now. Prioritize a functional permission simulator and a detailed denial investigation workflow over decorative elements. Do not stop after creating only the dashboard.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/bd18d93e-3598-4d9e-8992-4fff23d08566).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
